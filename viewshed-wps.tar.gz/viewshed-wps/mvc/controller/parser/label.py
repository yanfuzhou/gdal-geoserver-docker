VIEWSHED_LABEL = {
    "coordinates": 'coordinates',
    "distance": 'distance',
    "height": 'height',
    "offset": 'offset',
    "swath": 'swath',
    "curvature": 'curvature',
    "refraction": 'refraction',
    "k": 'k',
    "use_swath": 'use_swath',
    "earth_radius": 'earth_radius',
    "resolution": 'resolution',
    "esri": 'esri'
}
